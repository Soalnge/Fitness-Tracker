// ===============================
// WEIGHT CHART
// ===============================
const weightCtx = document.getElementById("weightChart");

new Chart(weightCtx, {
    type: "bar",
    data: {
        labels: ["Jan", "Feb", "Mar", "Apr", "May", "Jun"],
        datasets: [{
            label: "Weight",
            data: [100, 95, 90, 85, 80, 75],
            backgroundColor: "#4cc2ff"
        }]
    },
    options: {
        responsive: true,
        scales: {
            y: { beginAtZero: true }
        }
    }
});

// ===============================
// RUNNING CHART
// ===============================
const runningCtx = document.getElementById("runningChart");

new Chart(runningCtx, {
    type: "bar",
    data: {
        labels: ["Jan", "Feb", "Mar", "Apr", "May", "Jun"],
        datasets: [{
            label: "Running",
            data: [2, 2.5, 3, 3.5, 4, 4.2],
            backgroundColor: "#4cc2ff"
        }]
    },
    options: {
        responsive: true,
        scales: {
            y: { beginAtZero: true }
        }
    }
});
